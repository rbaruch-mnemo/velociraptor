// Accessor to make the registry available via OS API

package registry
