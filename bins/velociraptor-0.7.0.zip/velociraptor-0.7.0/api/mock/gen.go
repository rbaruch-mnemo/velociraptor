//go:generate mockgen  -destination api_mock.go www.velocidex.com/golang/velociraptor/api/proto APIClient,API_WatchEventClient

package mock_proto
