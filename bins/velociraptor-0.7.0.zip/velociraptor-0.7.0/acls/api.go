package acls

import "errors"

var (
	PermissionDenied = errors.New("PermissionDenied")
)
